//creating an array and passing the number, questions, options, and answers

let questions = [
  {
    numb: 1,
    question: "Which of the following is most impactful?",
    answer: "Tropical Forest Restoration",
    options: [
      "LED Lighting",
      "Tropical Forest Restoration",
      "Building Automation",
      "Perennial Staple Crops"
    ]
  },
  {
    numb: 2,
    question: "Which of the following is most impactful?",
    answer: "Alternative Refrigerants",
    options: [
      "Alternative Refrigerants",
      "Methane Digesters",
      "Micro Wind Turbines",
      "Silvopasture"
    ]
  },
  {
    numb: 3,
    question: "Which of the following is most impactful?",
    answer: "Insulation",
    options: [
      "Composting",
      "Waste-to-Energy",
      "Conservation Agriculture",
      "Insulation"
    ]
  },
  {
    numb: 4,
    question: "Which of the following is most impactful?",
    answer: "Reduced Food Waste",
    options: [
      "Recycled Paper",
      "Reduced Food Waste",
      "Telepresence",
      "Plant-Rich Diets"
    ]
  },
  {
    numb: 5,
    question: "Which of the following is most impactful?",
    answer: "Peatlands",
    options: [
      "Recycling",
      "Peatlands",
      "Public Transit",
      "District Heating"
    ]
  },
];
function start() {
  window.location = "game.html";
}

